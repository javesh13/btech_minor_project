import third as dm
client = {}
ip = {}
port = {}


def process_client(c, i, p):
	data = "a"
	while len(data):
	    data = c.recv(2048)
	    data = data.split("28")
	    data = data[1:]
	    for i in range(len(data)):
	        data[i] = "12" + data[i]
	    for item in data:
	    	dm.process_data(c, item)
