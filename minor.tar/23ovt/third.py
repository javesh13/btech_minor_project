import fourth as dc
from threading import Thread

fun_dic = {"1001":dc.decode_1001, "1002":dc.decode_1002,"1003":dc.decode_1003,"1004":dc.decode_1004,
        "3001": dc.decode_3001, "3002":dc.decode_3002, "3003":dc.decode_3003, 
        "3004": dc.decode_3004, "3005":dc.decode_3005 }

def process_data(con, data):
    code = data[2:6]
    t1 = ""
    if code == "1004":
        t1 = Thread(target = dc.decode_1004, args = (con, data))
        t1.start()
    else:
        t1 = Thread(target = fun_dic[code], args = ((data,)))
        t1.start()
    
